# Avora design reference (mockup)

These are the screens of the approved "Dawn" mockup, one file per screen (390 px wide phone screens), plus canvas.json which lists them in order.

- Each .dc.html file is plain HTML with inline styles. Open it in a text editor to read the exact colours, sizes, spacing, fonts and layout of that screen.
- They need the design canvas's runtime to display, so they will not render correctly by double-clicking. For a visual check, use exported images or PDF of the screens from the mockup page, if the owner supplies them.
- They are reference markup, not production code. Rebuild each screen in the app's real stack, matching what the files show.
- All text, names, topics, words and numbers are sample content only.

Screens: Login (login encouragement), Main (Today), Menu, Profile, Parent (parent area), DM (direct message), StudentCard (admin), MessagingSettings (admin), Lobby (live exam lobby), LiveControl (admin live session panel), GettingStarted (study time and starting check), Mistakes (My mistakes), GroupHome (channels), Chat (WhatsApp-style group chat), EnglishDaily, Rule (concord lesson), Oral (oral English lesson), CBT (exercise), DailyWord, ThisWeek (all subjects), Objectives (topic objectives), Constellation.
